# Android App Project Template
A template repository to create Android apps. It contains all the necessary files in the .gitignore.
